package SeleniumFrameworkDesign.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import SeleniumFrameworkDesign.AbstractComponents.AbstractComponent;

public class CheckoutPage extends AbstractComponent{
WebDriver driver;
Actions a = new Actions(driver);
@FindBy(css=".totalRow button")
WebElement ele1;
@FindBy(css="[placeholder='Select Country']")
WebElement dropdown;
By resultby=By.cssSelector(".ta-results");
@FindBy(xpath="//button[contains(@class,'ta-item')])[2]")
WebElement option;
@FindBy(css=".action__submit")
WebElement submit;

@FindBy(css=".hero-primary")
WebElement text1;

	public CheckoutPage(WebDriver driver) {
		// TODO Auto-generated constructor stub
		super(driver);
		this.driver=driver;
		PageFactory.initElements(driver, this);
		
		
	}
public void getcheckout(String country) {
	ele1.click();
	a.sendKeys(dropdown, country).build().perform();
	WaitforElementtoAppear(resultby);
	option.click();
	submit.click();
}
	public String getmessage() {
		String text2 = text1.getText();
		return text2;
	}
}
