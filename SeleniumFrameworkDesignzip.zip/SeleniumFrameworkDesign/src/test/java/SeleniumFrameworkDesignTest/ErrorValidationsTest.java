package SeleniumFrameworkDesignTest;

import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import SeleniumFrameworkDesign.pageobjects.CheckoutPage;
import SeleniumFrameworkDesign.pageobjects.Landingpage;
import SeleniumFrameworkDesign.pageobjects.cartpage;
import SeleniumFrameworkDesign.pageobjects.productcatalogue;
import SeleniumFrameworkDesignTest.TestComponents.BaseTest;

public class ErrorValidationsTest extends BaseTest {

	@Test(groups= {"errorhandling"})
	public void LoginErrorValidation() throws IOException {
		
		// TODO Auto-generated method stub
		lp.logintoapplication("anshika@gmail.com", "Iamking000");
		Assert.assertEquals("Incorrect email or password", lp.getErrormessage());
		
	}
	@Test
	public void ProductValidation() throws IOException {
		
		// TODO Auto-generated method stub
		String productname="ZARA COAT 3";
		productcatalogue pc=lp.logintoapplication("rahulshetty@gmail.com", "Iamking@000");
		List<WebElement>list1=pc.getproductlist();
		pc.addtocart(productname);
		cartpage cp=pc.gotocart();
		Boolean match=cp.getcartproducts("ZARA COAT 33");
		Assert.assertTrue(match);
		
	}
}
